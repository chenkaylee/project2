import { MongoClient } from 'mongodb';

const client = await MongoClient.connect('mongodb://localhost:27017/');
const coll = client.db('limitedEditionLines').collection('ChannelListings');
const result = await coll.updateOne(
  { listing_id: 'specific_listing_id' },
  { $bit: { listing_active: { xor: 1 } } }
);
console.log(result);
await client.close();