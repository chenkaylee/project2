import { MongoClient } from 'mongodb';

const client = await MongoClient.connect('mongodb://localhost:27017/');
const coll = client.db('limitedEditionLines').collection('SalesRecords');
const count = await coll.countDocuments({ user_id: 'specific_user_id' });
console.log(`Number of sales records for user: ${count}`);
await client.close();