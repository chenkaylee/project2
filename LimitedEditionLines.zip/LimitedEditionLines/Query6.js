import { MongoClient } from 'mongodb';

const agg = [
  {
    $group: {
      _id: '$product_id',
      Count: { $sum: 1 }
    }
  },
  {
    $lookup: {
      from: 'Products',
      localField: '_id',
      foreignField: 'product_id',
      as: 'product'
    }
  },
  {
    $unwind: '$product'
  },
  {
    $sort: { 'product.name': 1 }
  },
  {
    $project: {
      ProductName: '$product.name',
      VariantCount: '$Count'
    }
  }
];

const client = await MongoClient.connect('mongodb://localhost:27017/');
const coll = client.db('limitedEditionLines').collection('ProductVariants');
const cursor = coll.aggregate(agg);
const result = await cursor.toArray();
console.log(result);
await client.close();