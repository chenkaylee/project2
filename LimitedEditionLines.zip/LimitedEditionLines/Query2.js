import { MongoClient } from 'mongodb';

const matchCriteria = {
  $or: [
    { 'LimitedEditionLines.end_date': { $gt: new Date('2023-01-01') } },
    { 'ChannelListings.quantity_listed': { $gt: 100 } }
  ]
};

const client = await MongoClient.connect('mongodb://localhost:27017/');
const coll = client.db('limitedEditionLines').collection('Products');
const cursor = coll.find(matchCriteria);
const result = await cursor.toArray();
console.log(result);
await client.close();