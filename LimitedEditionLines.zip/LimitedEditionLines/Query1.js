import { MongoClient } from 'mongodb';

const agg = [
  {
    $lookup: {
      from: 'SalesRecords',
      localField: 'product_id',
      foreignField: 'product_id',
      as: 'sales'
    }
  },
  {
    $unwind: '$sales'
  },
  {
    $group: {
      _id: '$material',
      TotalSales: { $sum: '$sales.quantity_sold' }
    }
  }
];

const client = await MongoClient.connect('mongodb://localhost:27017/');
const coll = client.db('limitedEditionLines').collection('Products');
const cursor = coll.aggregate(agg);
const result = await cursor.toArray();
console.log(result);
await client.close();